// Payment page for Your Copilot
const stripe = Stripe('pk_live_51Pa561BGL9UZIi22MaqnyiBt4hPMFKa4DV3VpiXHq1NN6pLo2kQZjex885zh4mXddmXP2GRY5WHwb4RnYPJFcc1v00oYRGF3pO');

let selectedPlan = 'pro'; // Default to Pro plan

document.addEventListener('DOMContentLoaded', function() {
    const planCards = document.querySelectorAll('.plan-card');
    const paymentButton = document.getElementById('paymentButton');
    const loading = document.getElementById('loading');
    const errorMessage = document.getElementById('errorMessage');
    const successMessage = document.getElementById('successMessage');

    // Plan selection
    planCards.forEach(card => {
        card.addEventListener('click', function() {
            // Remove selected class from all cards
            planCards.forEach(c => c.classList.remove('selected'));
            
            // Add selected class to clicked card
            this.classList.add('selected');
            
            // Update selected plan
            selectedPlan = this.dataset.plan;
            
            // Update button text
            const planName = selectedPlan === 'basic' ? 'Basic' : 'Pro';
            const planPrice = selectedPlan === 'basic' ? '$1.99' : '$3.99';
            paymentButton.textContent = `Subscribe to ${planName} Plan - ${planPrice}/month`;
        });
    });

    // Payment button click
    paymentButton.addEventListener('click', async function() {
        try {
            // Show loading
            paymentButton.disabled = true;
            loading.style.display = 'block';
            errorMessage.style.display = 'none';

            // Create checkout session
            const response = await fetch('https://your-copilot-for-every-page-you-visit.onrender.com/api/create-checkout-session', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    plan: selectedPlan
                })
            });

            const session = await response.json();

            if (session.error) {
                throw new Error(session.error);
            }

            // Redirect to Stripe Checkout
            const result = await stripe.redirectToCheckout({
                sessionId: session.id
            });

            if (result.error) {
                throw new Error(result.error.message);
            }

        } catch (error) {
            console.error('Payment error:', error);
            errorMessage.textContent = error.message || 'Payment failed. Please try again.';
            errorMessage.style.display = 'block';
            paymentButton.disabled = false;
            loading.style.display = 'none';
        }
    });
});
